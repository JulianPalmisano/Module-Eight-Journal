package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String getChecksum() {
        // Example static data
        String data = "Hello World Check Sum!";
        String checksum = ChecksumUtil.generateSHA256Checksum(data);
        
        return "Data: " + data + "\nSHA-256 Checksum: " + checksum;
    }
}
